Michael Hoppal

Program 4

Analysis in README.pdf

Makefile only makes one excutable depending on which computer you are one. If you are on the cray it will create jacobi-cray if you are on the cs departments it will create jacobi-dept.

